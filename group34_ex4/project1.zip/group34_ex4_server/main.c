
#include "Server.h"


int main(int argc, char *argv[])
{
	MainServer(argv);
	return 0;
}